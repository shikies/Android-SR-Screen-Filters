package com.anime4k.screen;

import android.graphics.Bitmap;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

/**
 * Anime4K 超分渲染器 — 使用 OpenGL ES 2.0 实现。
 *
 * v1.3 变更：
 * - renderToScreen() 中 glClearColor 的 Alpha 从 1 改为 0，
 *   与 SurfaceHolder.setFormat(PixelFormat.TRANSLUCENT) 保持一致，
 *   避免黑色底色参与合成导致画面偏暗。
 */
public class Anime4KRenderer {

    private static final String TAG = "Anime4KRenderer";

    private static final String VERTEX_SHADER =
            "attribute vec4 aPosition;\n" +
            "attribute vec2 aTexCoord;\n" +
            "varying vec2 vTexCoord;\n" +
            "void main() {\n" +
            "    gl_Position = aPosition;\n" +
            "    vTexCoord = aTexCoord;\n" +
            "}\n";

    private static final String FRAG_PASSTHROUGH =
            "precision mediump float;\n" +
            "varying vec2 vTexCoord;\n" +
            "uniform sampler2D uTexture;\n" +
            "void main() {\n" +
            "    gl_FragColor = texture2D(uTexture, vTexCoord);\n" +
            "}\n";

    private static final String FRAG_LUMA =
            "precision mediump float;\n" +
            "varying vec2 vTexCoord;\n" +
            "uniform sampler2D uTexture;\n" +
            "void main() {\n" +
            "    vec4 c = texture2D(uTexture, vTexCoord);\n" +
            "    float luma = dot(vec3(0.299, 0.587, 0.114), c.rgb);\n" +
            "    gl_FragColor = vec4(luma, 0.0, 0.0, 1.0);\n" +
            "}\n";

    private static final String FRAG_GRAD_X1 =
            "precision mediump float;\n" +
            "varying vec2 vTexCoord;\n" +
            "uniform sampler2D uLuma;\n" +
            "uniform vec2 uTexelSize;\n" +
            "void main() {\n" +
            "    float l = texture2D(uLuma, vTexCoord + vec2(-uTexelSize.x, 0.0)).r;\n" +
            "    float c = texture2D(uLuma, vTexCoord).r;\n" +
            "    float r = texture2D(uLuma, vTexCoord + vec2(uTexelSize.x, 0.0)).r;\n" +
            "    float xgrad = (-l + r);\n" +
            "    float ygrad = (l + c + c + r);\n" +
            "    gl_FragColor = vec4(xgrad * 0.5 + 0.5, ygrad * 0.25 + 0.5, 0.0, 1.0);\n" +
            "}\n";

    private static final String FRAG_GRAD_Y1 =
            "precision mediump float;\n" +
            "varying vec2 vTexCoord;\n" +
            "uniform sampler2D uGrad;\n" +
            "uniform vec2 uTexelSize;\n" +
            "uniform float uRefineStrength;\n" +
            "\n" +
            "float power_function(float x) {\n" +
            "    float x2 = x * x;\n" +
            "    float x3 = x2 * x;\n" +
            "    float x4 = x2 * x2;\n" +
            "    float x5 = x2 * x3;\n" +
            "    return 11.68129591*x5 - 42.46906057*x4 + 60.28286266*x3\n" +
            "         - 41.84451327*x2 + 14.05517353*x - 1.081521930;\n" +
            "}\n" +
            "\n" +
            "void main() {\n" +
            "    float tx = texture2D(uGrad, vTexCoord + vec2(0.0, -uTexelSize.y)).r * 2.0 - 1.0;\n" +
            "    float cx = texture2D(uGrad, vTexCoord).r * 2.0 - 1.0;\n" +
            "    float bx = texture2D(uGrad, vTexCoord + vec2(0.0, uTexelSize.y)).r * 2.0 - 1.0;\n" +
            "    float ty = texture2D(uGrad, vTexCoord + vec2(0.0, -uTexelSize.y)).g * 4.0 - 2.0;\n" +
            "    float by = texture2D(uGrad, vTexCoord + vec2(0.0, uTexelSize.y)).g * 4.0 - 2.0;\n" +
            "    float xgrad = (tx + cx + cx + bx);\n" +
            "    float ygrad = (-ty + by);\n" +
            "    float sobel = clamp(sqrt(xgrad * xgrad + ygrad * ygrad), 0.0, 1.0);\n" +
            "    float dval = clamp(power_function(sobel) * uRefineStrength, 0.0, 1.0);\n" +
            "    gl_FragColor = vec4(sobel * 0.5 + 0.5, dval, 0.0, 1.0);\n" +
            "}\n";

    private static final String FRAG_GRAD_X2 =
            "precision mediump float;\n" +
            "varying vec2 vTexCoord;\n" +
            "uniform sampler2D uLumad;\n" +
            "uniform vec2 uTexelSize;\n" +
            "void main() {\n" +
            "    float dval = texture2D(uLumad, vTexCoord).g;\n" +
            "    if (dval < 0.1) {\n" +
            "        gl_FragColor = vec4(0.5, 0.5, 0.0, 1.0);\n" +
            "        return;\n" +
            "    }\n" +
            "    float sobel = texture2D(uLumad, vTexCoord).r * 2.0 - 1.0;\n" +
            "    float l = texture2D(uLumad, vTexCoord + vec2(-uTexelSize.x, 0.0)).r * 2.0 - 1.0;\n" +
            "    float r = texture2D(uLumad, vTexCoord + vec2(uTexelSize.x, 0.0)).r * 2.0 - 1.0;\n" +
            "    float xgrad = (-l + r);\n" +
            "    float ygrad = (l + sobel + sobel + r);\n" +
            "    gl_FragColor = vec4(xgrad * 0.5 + 0.5, ygrad * 0.25 + 0.5, 0.0, 1.0);\n" +
            "}\n";

    private static final String FRAG_GRAD_Y2 =
            "precision mediump float;\n" +
            "varying vec2 vTexCoord;\n" +
            "uniform sampler2D uLumad;\n" +
            "uniform sampler2D uLumamm;\n" +
            "uniform vec2 uTexelSize;\n" +
            "void main() {\n" +
            "    float dval = texture2D(uLumad, vTexCoord).g;\n" +
            "    if (dval < 0.1) {\n" +
            "        gl_FragColor = vec4(0.5, 0.5, 0.0, 1.0);\n" +
            "        return;\n" +
            "    }\n" +
            "    float tx = texture2D(uLumamm, vTexCoord + vec2(0.0, -uTexelSize.y)).r * 2.0 - 1.0;\n" +
            "    float cx = texture2D(uLumamm, vTexCoord).r * 2.0 - 1.0;\n" +
            "    float bx = texture2D(uLumamm, vTexCoord + vec2(0.0, uTexelSize.y)).r * 2.0 - 1.0;\n" +
            "    float ty = texture2D(uLumamm, vTexCoord + vec2(0.0, -uTexelSize.y)).g * 4.0 - 2.0;\n" +
            "    float by = texture2D(uLumamm, vTexCoord + vec2(0.0, uTexelSize.y)).g * 4.0 - 2.0;\n" +
            "    float xgrad = (tx + cx + cx + bx);\n" +
            "    float ygrad = (-ty + by);\n" +
            "    float norm = sqrt(xgrad * xgrad + ygrad * ygrad);\n" +
            "    if (norm <= 0.001) {\n" +
            "        gl_FragColor = vec4(0.5, 0.5, 0.0, 1.0);\n" +
            "        return;\n" +
            "    }\n" +
            "    gl_FragColor = vec4(xgrad / norm * 0.5 + 0.5, ygrad / norm * 0.5 + 0.5, 0.0, 1.0);\n" +
            "}\n";

    private static final String FRAG_APPLY =
            "precision mediump float;\n" +
            "varying vec2 vTexCoord;\n" +
            "uniform sampler2D uTexture;\n" +
            "uniform sampler2D uLumad;\n" +
            "uniform sampler2D uLumamm;\n" +
            "uniform vec2 uTexelSize;\n" +
            "void main() {\n" +
            "    float dval = texture2D(uLumad, vTexCoord).g;\n" +
            "    vec4 original = texture2D(uTexture, vTexCoord);\n" +
            "    if (dval < 0.1) {\n" +
            "        gl_FragColor = original;\n" +
            "        return;\n" +
            "    }\n" +
            "    vec2 dir = texture2D(uLumamm, vTexCoord).rg * 2.0 - 1.0;\n" +
            "    if (abs(dir.x) + abs(dir.y) <= 0.0001) {\n" +
            "        gl_FragColor = original;\n" +
            "        return;\n" +
            "    }\n" +
            "    float xpos = -sign(dir.x);\n" +
            "    float ypos = -sign(dir.y);\n" +
            "    vec4 xval = texture2D(uTexture, vTexCoord + vec2(uTexelSize.x * xpos, 0.0));\n" +
            "    vec4 yval = texture2D(uTexture, vTexCoord + vec2(0.0, uTexelSize.y * ypos));\n" +
            "    float xyratio = abs(dir.x) / (abs(dir.x) + abs(dir.y));\n" +
            "    vec4 avg = xyratio * xval + (1.0 - xyratio) * yval;\n" +
            "    gl_FragColor = avg * dval + original * (1.0 - dval);\n" +
            "}\n";

    private static final float[] QUAD_VERTICES = {
            -1f, -1f, 0f, 0f,
             1f, -1f, 1f, 0f,
            -1f,  1f, 0f, 1f,
             1f,  1f, 1f, 1f
    };

    private static final float[] QUAD_VERTICES_FLIPPED = {
            -1f, -1f, 0f, 1f,
             1f, -1f, 1f, 1f,
            -1f,  1f, 0f, 0f,
             1f,  1f, 1f, 0f
    };

    private FloatBuffer vertexBuffer;
    private FloatBuffer vertexBufferFlipped;

    private int programLuma, programGradX1, programGradY1;
    private int programGradX2, programGradY2;
    private int programApply, programPassthrough;

    private int inputTexture, lumaTexture, lumadTexture, lumammTexture, outputTexture;
    private int inputWidth, inputHeight, outputWidth, outputHeight;
    private int[] fbo = new int[5];

    private float refineStrength = 0.5f;
    private boolean initialized = false;

    public Anime4KRenderer() {
        ByteBuffer bb = ByteBuffer.allocateDirect(QUAD_VERTICES.length * 4);
        bb.order(ByteOrder.nativeOrder());
        vertexBuffer = bb.asFloatBuffer();
        vertexBuffer.put(QUAD_VERTICES);
        vertexBuffer.position(0);

        ByteBuffer bb2 = ByteBuffer.allocateDirect(QUAD_VERTICES_FLIPPED.length * 4);
        bb2.order(ByteOrder.nativeOrder());
        vertexBufferFlipped = bb2.asFloatBuffer();
        vertexBufferFlipped.put(QUAD_VERTICES_FLIPPED);
        vertexBufferFlipped.position(0);
    }

    public void setRefineStrength(float strength) {
        this.refineStrength = strength;
    }

    public void init(int inW, int inH, int outW, int outH) {
        if (initialized) release();

        inputWidth = inW;
        inputHeight = inH;
        outputWidth = outW;
        outputHeight = outH;

        programLuma = createProgram(VERTEX_SHADER, FRAG_LUMA);
        programGradX1 = createProgram(VERTEX_SHADER, FRAG_GRAD_X1);
        programGradY1 = createProgram(VERTEX_SHADER, FRAG_GRAD_Y1);
        programGradX2 = createProgram(VERTEX_SHADER, FRAG_GRAD_X2);
        programGradY2 = createProgram(VERTEX_SHADER, FRAG_GRAD_Y2);
        programApply = createProgram(VERTEX_SHADER, FRAG_APPLY);
        programPassthrough = createProgram(VERTEX_SHADER, FRAG_PASSTHROUGH);

        GLES20.glGenFramebuffers(5, fbo, 0);

        inputTexture = createTexture(inputWidth, inputHeight);
        lumaTexture = createTexture(inputWidth, inputHeight);
        lumadTexture = createTexture(outputWidth, outputHeight);
        lumammTexture = createTexture(outputWidth, outputHeight);
        outputTexture = createTexture(outputWidth, outputHeight);

        attachTextureToFBO(fbo[0], lumaTexture);
        attachTextureToFBO(fbo[1], lumadTexture);
        attachTextureToFBO(fbo[2], lumadTexture);
        attachTextureToFBO(fbo[3], lumammTexture);
        attachTextureToFBO(fbo[4], outputTexture);

        initialized = true;
        Log.d(TAG, "Initialized: " + inW + "x" + inH + " -> " + outW + "x" + outH);
    }

    public int process(Bitmap bitmap) {
        if (!initialized) return 0;

        // Upload bitmap to input texture
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, inputTexture);
        GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bitmap);

        // Pass 1: Extract luma
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[0]);
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
                GLES20.GL_TEXTURE_2D, lumaTexture, 0);
        GLES20.glViewport(0, 0, inputWidth, inputHeight);
        drawQuad(programLuma, new int[]{inputTexture}, new String[]{"uTexture"});

        // Pass 2: Gradient X1
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[1]);
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
                GLES20.GL_TEXTURE_2D, lumadTexture, 0);
        GLES20.glViewport(0, 0, outputWidth, outputHeight);
        GLES20.glUseProgram(programGradX1);
        setTexelSize(programGradX1, inputWidth, inputHeight);
        drawQuad(programGradX1, new int[]{lumaTexture}, new String[]{"uLuma"});

        // Pass 3: Gradient Y1
        int tempTex = createTexture(outputWidth, outputHeight);
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[2]);
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
                GLES20.GL_TEXTURE_2D, tempTex, 0);
        GLES20.glViewport(0, 0, outputWidth, outputHeight);
        GLES20.glUseProgram(programGradY1);
        setTexelSize(programGradY1, outputWidth, outputHeight);
        int loc = GLES20.glGetUniformLocation(programGradY1, "uRefineStrength");
        GLES20.glUniform1f(loc, refineStrength);
        drawQuad(programGradY1, new int[]{lumadTexture}, new String[]{"uGrad"});

        // Copy temp -> lumad
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[1]);
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
                GLES20.GL_TEXTURE_2D, lumadTexture, 0);
        GLES20.glViewport(0, 0, outputWidth, outputHeight);
        drawQuad(programPassthrough, new int[]{tempTex}, new String[]{"uTexture"});

        // Pass 4: Gradient X2
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[3]);
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
                GLES20.GL_TEXTURE_2D, lumammTexture, 0);
        GLES20.glViewport(0, 0, outputWidth, outputHeight);
        GLES20.glUseProgram(programGradX2);
        setTexelSize(programGradX2, outputWidth, outputHeight);
        drawQuad(programGradX2, new int[]{lumadTexture}, new String[]{"uLumad"});

        // Pass 5: Gradient Y2
        int tempTex2 = createTexture(outputWidth, outputHeight);
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[2]);
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
                GLES20.GL_TEXTURE_2D, tempTex2, 0);
        GLES20.glViewport(0, 0, outputWidth, outputHeight);
        GLES20.glUseProgram(programGradY2);
        setTexelSize(programGradY2, outputWidth, outputHeight);
        drawQuad(programGradY2, new int[]{lumadTexture, lumammTexture}, new String[]{"uLumad", "uLumamm"});

        // Copy temp2 -> lumamm
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[3]);
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
                GLES20.GL_TEXTURE_2D, lumammTexture, 0);
        GLES20.glViewport(0, 0, outputWidth, outputHeight);
        drawQuad(programPassthrough, new int[]{tempTex2}, new String[]{"uTexture"});

        // Pass 6: Apply
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[4]);
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
                GLES20.GL_TEXTURE_2D, outputTexture, 0);
        GLES20.glViewport(0, 0, outputWidth, outputHeight);
        GLES20.glUseProgram(programApply);
        setTexelSize(programApply, inputWidth, inputHeight);
        drawQuad(programApply, new int[]{inputTexture, lumadTexture, lumammTexture},
                new String[]{"uTexture", "uLumad", "uLumamm"});

        // Cleanup temp textures
        GLES20.glDeleteTextures(2, new int[]{tempTex, tempTex2}, 0);
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);

        return outputTexture;
    }

    public void renderToScreen(int texture, int screenWidth, int screenHeight) {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
        GLES20.glViewport(0, 0, screenWidth, screenHeight);
        // v1.3 修复：使用完全透明色清除，与 TRANSLUCENT 格式保持一致
        GLES20.glClearColor(0, 0, 0, 0);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        drawQuadWithBuffer(programPassthrough, new int[]{texture}, new String[]{"uTexture"}, vertexBufferFlipped);
    }

    private void drawQuad(int program, int[] textures, String[] uniformNames) {
        drawQuadWithBuffer(program, textures, uniformNames, vertexBuffer);
    }

    private void drawQuadWithBuffer(int program, int[] textures, String[] uniformNames, FloatBuffer vbuf) {
        GLES20.glUseProgram(program);
        int posLoc = GLES20.glGetAttribLocation(program, "aPosition");
        int texLoc = GLES20.glGetAttribLocation(program, "aTexCoord");

        vbuf.position(0);
        GLES20.glEnableVertexAttribArray(posLoc);
        GLES20.glVertexAttribPointer(posLoc, 2, GLES20.GL_FLOAT, false, 16, vbuf);

        vbuf.position(2);
        GLES20.glEnableVertexAttribArray(texLoc);
        GLES20.glVertexAttribPointer(texLoc, 2, GLES20.GL_FLOAT, false, 16, vbuf);

        for (int i = 0; i < textures.length; i++) {
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + i);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textures[i]);
            int uLoc = GLES20.glGetUniformLocation(program, uniformNames[i]);
            GLES20.glUniform1i(uLoc, i);
        }

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        GLES20.glDisableVertexAttribArray(posLoc);
        GLES20.glDisableVertexAttribArray(texLoc);
    }

    private void setTexelSize(int program, int w, int h) {
        int loc = GLES20.glGetUniformLocation(program, "uTexelSize");
        if (loc >= 0) {
            GLES20.glUniform2f(loc, 1.0f / w, 1.0f / h);
        }
    }

    private int createTexture(int width, int height) {
        int[] tex = new int[1];
        GLES20.glGenTextures(1, tex, 0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[0]);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, width, height, 0,
                GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null);
        return tex[0];
    }

    private void attachTextureToFBO(int fboId, int texId) {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fboId);
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
                GLES20.GL_TEXTURE_2D, texId, 0);
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
    }

    private int createProgram(String vertexSource, String fragmentSource) {
        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexSource);
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource);
        int program = GLES20.glCreateProgram();
        GLES20.glAttachShader(program, vertexShader);
        GLES20.glAttachShader(program, fragmentShader);
        GLES20.glLinkProgram(program);

        int[] linkStatus = new int[1];
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linkStatus, 0);
        if (linkStatus[0] != GLES20.GL_TRUE) {
            Log.e(TAG, "Program link error: " + GLES20.glGetProgramInfoLog(program));
            GLES20.glDeleteProgram(program);
            return 0;
        }

        GLES20.glDeleteShader(vertexShader);
        GLES20.glDeleteShader(fragmentShader);
        return program;
    }

    private int loadShader(int type, String source) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, source);
        GLES20.glCompileShader(shader);

        int[] compiled = new int[1];
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0);
        if (compiled[0] != GLES20.GL_TRUE) {
            Log.e(TAG, "Shader compile error: " + GLES20.glGetShaderInfoLog(shader));
            GLES20.glDeleteShader(shader);
            return 0;
        }
        return shader;
    }

    public void release() {
        if (initialized) {
            GLES20.glDeleteProgram(programLuma);
            GLES20.glDeleteProgram(programGradX1);
            GLES20.glDeleteProgram(programGradY1);
            GLES20.glDeleteProgram(programGradX2);
            GLES20.glDeleteProgram(programGradY2);
            GLES20.glDeleteProgram(programApply);
            GLES20.glDeleteProgram(programPassthrough);
            GLES20.glDeleteFramebuffers(5, fbo, 0);
            GLES20.glDeleteTextures(5, new int[]{inputTexture, lumaTexture, lumadTexture, lumammTexture, outputTexture}, 0);
            initialized = false;
        }
    }
}
