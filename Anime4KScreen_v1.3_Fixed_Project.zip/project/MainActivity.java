package com.anime4k.screen;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.util.List;

/**
 * v1.3 变更：
 * - 恢复无障碍开关 UI（无障碍模式现在使用 TYPE_ACCESSIBILITY_OVERLAY，是正确的实现路径）
 * - 无障碍模式（推荐）：使用 TYPE_ACCESSIBILITY_OVERLAY 可信窗口，触摸可穿透到任何应用
 * - 传统模式（降级）：使用 TYPE_APPLICATION_OVERLAY + alpha<=0.8，触摸可穿透但叠加层略微半透明
 */
public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_MEDIA_PROJECTION = 1001;
    private static final int REQUEST_OVERLAY_PERMISSION = 1002;

    private MaterialButton toggleButton;
    private MaterialButton accessibilityButton;
    private TextView statusText;
    private TextView fpsText;
    private SeekBar scaleSeekBar;
    private TextView scaleValue;
    private SeekBar strengthSeekBar;
    private TextView strengthValue;
    private SeekBar intervalSeekBar;
    private TextView intervalValue;
    private Switch accessibilitySwitch;
    private TextView accessibilityStatusText;

    private boolean isRunning = false;
    private SharedPreferences prefs;

    private BroadcastReceiver fpsReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if ("com.anime4k.screen.FPS_UPDATE".equals(intent.getAction())) {
                float fps = intent.getFloatExtra("fps", 0);
                fpsText.setText(String.format("FPS: %.1f", fps));
            } else if ("com.anime4k.screen.SERVICE_STOPPED".equals(intent.getAction())) {
                isRunning = false;
                updateUI();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("anime4k_prefs", MODE_PRIVATE);

        toggleButton = findViewById(R.id.toggleButton);
        accessibilityButton = findViewById(R.id.accessibilityButton);
        statusText = findViewById(R.id.statusText);
        fpsText = findViewById(R.id.fpsText);
        scaleValue = findViewById(R.id.scaleValue);
        strengthValue = findViewById(R.id.strengthValue);
        intervalValue = findViewById(R.id.intervalValue);
        scaleSeekBar = findViewById(R.id.scaleSeekBar);
        strengthSeekBar = findViewById(R.id.strengthSeekBar);
        intervalSeekBar = findViewById(R.id.intervalSeekBar);
        accessibilitySwitch = findViewById(R.id.accessibilitySwitch);
        accessibilityStatusText = findViewById(R.id.accessibilityStatusText);

        // 恢复保存的设置
        scaleSeekBar.setProgress(prefs.getInt("scale", 50));
        strengthSeekBar.setProgress(prefs.getInt("strength", 50));
        intervalSeekBar.setProgress(prefs.getInt("interval", 100));
        accessibilitySwitch.setChecked(prefs.getBoolean("useAccessibility", true));

        updateScaleLabel(scaleSeekBar.getProgress());
        updateStrengthLabel(strengthSeekBar.getProgress());
        updateIntervalLabel(intervalSeekBar.getProgress());

        scaleSeekBar.setOnSeekBarChangeListener(new SimpleSeekBarListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateScaleLabel(progress);
                prefs.edit().putInt("scale", progress).apply();
            }
        });

        strengthSeekBar.setOnSeekBarChangeListener(new SimpleSeekBarListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateStrengthLabel(progress);
                prefs.edit().putInt("strength", progress).apply();
            }
        });

        intervalSeekBar.setOnSeekBarChangeListener(new SimpleSeekBarListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateIntervalLabel(progress);
                prefs.edit().putInt("interval", progress).apply();
            }
        });

        toggleButton.setOnClickListener(v -> {
            if (isRunning) {
                stopUpscaling();
            } else {
                startUpscaling();
            }
        });

        // 恢复无障碍 UI 控件的可见性
        accessibilitySwitch.setVisibility(View.VISIBLE);
        accessibilityStatusText.setVisibility(View.VISIBLE);
        accessibilityButton.setVisibility(View.VISIBLE);

        accessibilitySwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean("useAccessibility", isChecked).apply();
            updateAccessibilityStatus();
        });

        accessibilityButton.setOnClickListener(v -> {
            if (accessibilitySwitch.isChecked() && !isAccessibilityServiceEnabled()) {
                showAccessibilityGuideDialog();
            } else {
                openAccessibilitySettings();
            }
        });

        IntentFilter filter = new IntentFilter();
        filter.addAction("com.anime4k.screen.FPS_UPDATE");
        filter.addAction("com.anime4k.screen.SERVICE_STOPPED");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(fpsReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(fpsReceiver, filter);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateAccessibilityStatus();
    }

    private void updateScaleLabel(int progress) {
        scaleValue.setText(progress + "%");
    }

    private void updateStrengthLabel(int progress) {
        strengthValue.setText(String.format("%.2f", progress / 100.0f));
    }

    private void updateIntervalLabel(int progress) {
        intervalValue.setText(progress + "ms");
    }

    private boolean isAccessibilityServiceEnabled() {
        AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        List<AccessibilityServiceInfo> enabledServices =
                am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        String expectedId = getPackageName() + "/" + TouchForwardingAccessibilityService.class.getCanonicalName();
        for (AccessibilityServiceInfo info : enabledServices) {
            if (info.getId().equals(expectedId)) {
                return true;
            }
        }
        return TouchForwardingAccessibilityService.isServiceRunning();
    }

    private void updateAccessibilityStatus() {
        boolean enabled = isAccessibilityServiceEnabled();
        boolean switchOn = accessibilitySwitch.isChecked();

        if (switchOn && enabled) {
            accessibilityStatusText.setText("无障碍叠加模式：已启用（推荐，全局触摸穿透）");
            accessibilityStatusText.setTextColor(0xFF4CAF50); // green
            accessibilityButton.setText("无障碍设置");
        } else if (switchOn && !enabled) {
            accessibilityStatusText.setText("无障碍叠加模式：未授权（请点击下方按钮开启）");
            accessibilityStatusText.setTextColor(0xFFFF9800); // orange
            accessibilityButton.setText("前往开启无障碍服务");
        } else {
            accessibilityStatusText.setText("传统穿透模式：叠加层 alpha=0.8（略微半透明）");
            accessibilityStatusText.setTextColor(0x88FFFFFF); // gray
            accessibilityButton.setText("无障碍设置");
        }
    }

    private void showAccessibilityGuideDialog() {
        new AlertDialog.Builder(this)
                .setTitle("开启无障碍服务")
                .setMessage("为了在 Android 12+ 上实现全局触摸穿透（操控任何应用），需要开启本应用的无障碍服务。\n\n"
                        + "开启后，叠加层将使用 TYPE_ACCESSIBILITY_OVERLAY（可信窗口），"
                        + "触摸可以穿透到任何应用，且叠加层完全不透明。\n\n"
                        + "步骤：\n"
                        + "1. 点击「前往设置」\n"
                        + "2. 找到「Anime4K Screen 触控转发」\n"
                        + "3. 开启服务并确认\n\n"
                        + "此服务仅用于创建可信叠加窗口，不会收集任何数据。\n\n"
                        + "如果不开启，将使用传统模式（叠加层略微半透明，alpha=0.8）。")
                .setPositiveButton("前往设置", (dialog, which) -> openAccessibilitySettings())
                .setNegativeButton("稍后（使用传统模式）", null)
                .show();
    }

    private void openAccessibilitySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "无法打开无障碍设置", Toast.LENGTH_SHORT).show();
        }
    }

    private void startUpscaling() {
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
            Toast.makeText(this, "请授予悬浮窗权限", Toast.LENGTH_LONG).show();
            return;
        }

        boolean useAccessibility = accessibilitySwitch.isChecked();
        if (useAccessibility && !isAccessibilityServiceEnabled()) {
            showAccessibilityGuideDialog();
            return;
        }

        MediaProjectionManager projectionManager =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_MEDIA_PROJECTION);
    }

    private void stopUpscaling() {
        Intent intent = new Intent(this, OverlayService.class);
        intent.setAction("STOP");
        startService(intent);
        isRunning = false;
        updateUI();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            if (Settings.canDrawOverlays(this)) {
                startUpscaling();
            } else {
                Toast.makeText(this, "需要悬浮窗权限才能运行", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        if (requestCode == REQUEST_MEDIA_PROJECTION) {
            if (resultCode == RESULT_OK && data != null) {
                Intent serviceIntent = new Intent(this, OverlayService.class);
                serviceIntent.setAction("START");
                serviceIntent.putExtra("resultCode", resultCode);
                serviceIntent.putExtra("data", data);
                serviceIntent.putExtra("scale", scaleSeekBar.getProgress());
                serviceIntent.putExtra("strength", strengthSeekBar.getProgress());
                serviceIntent.putExtra("interval", intervalSeekBar.getProgress());
                serviceIntent.putExtra("useAccessibility", accessibilitySwitch.isChecked());
                startForegroundService(serviceIntent);
                isRunning = true;
                updateUI();
                moveTaskToBack(true);
            } else {
                Toast.makeText(this, "需要屏幕录制权限", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void updateUI() {
        if (isRunning) {
            toggleButton.setText("停止超分");
            toggleButton.setBackgroundTintList(ColorStateList.valueOf(0xFFCF6679));
            statusText.setText("运行中");
            statusText.setTextColor(0xFF03DAC5);
        } else {
            toggleButton.setText("启动超分");
            toggleButton.setBackgroundTintList(ColorStateList.valueOf(0xFF6200EE));
            statusText.setText("已停止");
            statusText.setTextColor(0xFFFFFFFF);
            fpsText.setText("FPS: --");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(fpsReceiver);
        } catch (Exception e) {}
    }

    static abstract class SimpleSeekBarListener implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {}
        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {}
    }
}
