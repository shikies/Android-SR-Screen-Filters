package com.anime4k.screen;

import android.content.Context;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

/**
 * 触摸拦截视图 — 已弃用，不在主路径使用。
 *
 * 保留此类以备将来探索。注意其局限性：
 * dispatchGesture() 注入的手势目标是系统焦点窗口，
 * 而非坐标下方的窗口，因此无法实现"透过叠加层操控底层"的目标。
 *
 * v1.3 说明：
 * 当前使用 TYPE_ACCESSIBILITY_OVERLAY + FLAG_NOT_TOUCHABLE 方案，
 * 不再需要此类。
 */
public class TouchInterceptView extends SurfaceView {

    private static final String TAG = "TouchInterceptView";
    private static final int TOUCH_SLOP = 10;
    private static final long TAP_TIMEOUT = 200;
    private static final long LONG_PRESS_TIMEOUT = 500;

    private float downX, downY;
    private long downTime;
    private boolean isDragging = false;
    private boolean isMultiTouch = false;
    private boolean longPressTriggered = false;
    private Handler handler = new Handler();
    private Runnable longPressRunnable;

    private float pinchStartSpan;
    private float pinchCenterX, pinchCenterY;

    private SurfaceHolder.Callback surfaceCallback;

    public TouchInterceptView(Context context) {
        super(context);
    }

    public void setSurfaceCallback(SurfaceHolder.Callback callback) {
        this.surfaceCallback = callback;
        getHolder().addCallback(callback);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        TouchForwardingAccessibilityService service = TouchForwardingAccessibilityService.getInstance();
        if (service == null) {
            Log.w(TAG, "Accessibility service not running, touch not forwarded");
            // v1.3 修复：返回 false 让系统处理事件，而不是吞掉
            return false;
        }

        int action = event.getActionMasked();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                handleActionDown(event);
                break;
            case MotionEvent.ACTION_UP:
                handleActionUp(event, service);
                break;
            case MotionEvent.ACTION_MOVE:
                handleActionMove(event, service);
                break;
            case MotionEvent.ACTION_CANCEL:
                resetTouchState();
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                handlePointerDown(event);
                break;
            case MotionEvent.ACTION_POINTER_UP:
                handlePointerUp(event);
                break;
        }
        return true;
    }

    private void handleActionDown(MotionEvent event) {
        downX = event.getRawX();
        downY = event.getRawY();
        downTime = SystemClock.uptimeMillis();
        isDragging = false;
        isMultiTouch = false;
        longPressTriggered = false;
        cancelLongPress();

        longPressRunnable = () -> {
            if (!isDragging && !isMultiTouch) {
                longPressTriggered = true;
                TouchForwardingAccessibilityService svc = TouchForwardingAccessibilityService.getInstance();
                if (svc != null) {
                    svc.performLongPress(downX, downY, 1000);
                    Log.d(TAG, "Long press detected at (" + downX + ", " + downY + ")");
                }
            }
        };
        handler.postDelayed(longPressRunnable, LONG_PRESS_TIMEOUT);
    }

    private void handlePointerDown(MotionEvent event) {
        isMultiTouch = true;
        cancelLongPress();

        if (event.getPointerCount() == 2) {
            float dx = event.getX(0) - event.getX(1);
            float dy = event.getY(0) - event.getY(1);
            pinchStartSpan = (float) Math.sqrt(dx * dx + dy * dy);

            pinchCenterX = (event.getX(0) + event.getX(1)) / 2;
            pinchCenterY = (event.getY(0) + event.getY(1)) / 2;

            int[] location = new int[2];
            getLocationOnScreen(location);
            pinchCenterX += location[0];
            pinchCenterY += location[1];
        }
    }

    private void handleActionMove(MotionEvent event, TouchForwardingAccessibilityService service) {
        if (longPressTriggered) return;
        if (isMultiTouch) {
            cancelLongPress();
            return;
        }

        float currentX = event.getRawX();
        float currentY = event.getRawY();
        float deltaX = currentX - downX;
        float deltaY = currentY - downY;
        float distance = (float) Math.sqrt(deltaX * deltaX + deltaY * deltaY);

        if (distance > TOUCH_SLOP && !isDragging) {
            isDragging = true;
            cancelLongPress();
        }
    }

    private void handleActionUp(MotionEvent event, TouchForwardingAccessibilityService service) {
        cancelLongPress();

        if (longPressTriggered) {
            resetTouchState();
            return;
        }

        float upX = event.getRawX();
        float upY = event.getRawY();
        long elapsed = SystemClock.uptimeMillis() - downTime;

        if (isMultiTouch) {
            resetTouchState();
            return;
        }

        if (isDragging) {
            service.performSwipe(downX, downY, upX, upY, Math.max(elapsed, 50));
            Log.d(TAG, "Swipe detected from (" + downX + "," + downY + ") to (" + upX + "," + upY + "), duration=" + elapsed);
        } else {
            float deltaX = upX - downX;
            float deltaY = upY - downY;
            float distance = (float) Math.sqrt(deltaX * deltaX + deltaY * deltaY);

            if (distance <= TOUCH_SLOP && elapsed <= TAP_TIMEOUT) {
                service.performClick(downX, downY);
                Log.d(TAG, "Tap detected at (" + downX + ", " + downY + ")");
            } else if (distance <= TOUCH_SLOP) {
                service.performClick(downX, downY);
                Log.d(TAG, "Slow tap detected at (" + downX + ", " + downY + ")");
            }
        }
        resetTouchState();
    }

    private void handlePointerUp(MotionEvent event) {
        if (event.getPointerCount() == 2 && isMultiTouch) {
            float dx = event.getX(0) - event.getX(1);
            float dy = event.getY(0) - event.getY(1);
            float endSpan = (float) Math.sqrt(dx * dx + dy * dy);

            if (pinchStartSpan > 0 && Math.abs(endSpan - pinchStartSpan) > 30) {
                TouchForwardingAccessibilityService service = TouchForwardingAccessibilityService.getInstance();
                if (service != null) {
                    long elapsed = SystemClock.uptimeMillis() - downTime;
                    service.performPinch(pinchCenterX, pinchCenterY, pinchStartSpan, endSpan, Math.max(elapsed, 300));
                    Log.d(TAG, "Pinch detected: span " + pinchStartSpan + " -> " + endSpan);
                }
            }
        }
    }

    @Override
    public void cancelLongPress() {
        if (longPressRunnable != null) {
            handler.removeCallbacks(longPressRunnable);
            longPressRunnable = null;
        }
    }

    private void resetTouchState() {
        isDragging = false;
        isMultiTouch = false;
        longPressTriggered = false;
        pinchStartSpan = 0;
        cancelLongPress();
    }
}
