package com.anime4k.screen;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;

import java.nio.ByteBuffer;

/**
 * 核心前台服务：管理屏幕捕获、Anime4K 超分渲染和悬浮窗叠加显示。
 *
 * v1.3 变更：
 * - 修复 Android 12+ 上触摸无法穿透到其他应用的问题
 * - 支持两种叠加窗口模式：
 *   1. 无障碍模式（推荐）：使用 TYPE_ACCESSIBILITY_OVERLAY（可信窗口，不受 Untrusted Touch 限制）
 *   2. 传统模式（降级）：使用 TYPE_APPLICATION_OVERLAY + alpha <= 0.8（满足半透明豁免条件）
 * - 统一使用 FLAG_NOT_TOUCHABLE 实现触摸穿透
 * - renderToOverlay() 中添加 glClear() 消除残影
 */
public class OverlayService extends Service {

    private static final String TAG = "OverlayService";
    private static final String CHANNEL_ID = "anime4k_channel";
    private static final int NOTIFICATION_ID = 1;

    private WindowManager windowManager;
    private SurfaceView overlaySurfaceView;
    private WindowManager.LayoutParams overlayParams;

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;

    private HandlerThread processingThread;
    private Handler processingHandler;

    private Anime4KRenderer renderer;

    private int screenWidth, screenHeight, screenDensity;
    private int captureWidth, captureHeight;
    private float captureScale = 0.5f;
    private float refineStrength = 0.5f;
    private int frameInterval = 100; // ms

    private boolean isRunning = false;
    private long lastFrameTime = 0;
    private int frameCount = 0;
    private long fpsStartTime = 0;

    // EGL context for offscreen rendering
    private EGLDisplay eglDisplay;
    private EGLContext eglContext;
    private EGLSurface eglSurface;
    private EGLSurface eglOverlaySurface;

    private boolean surfaceReady = false;
    private Surface overlayOutputSurface;

    // 触摸模式：true = 使用无障碍服务的 TYPE_ACCESSIBILITY_OVERLAY（推荐），
    //           false = 使用 TYPE_APPLICATION_OVERLAY + alpha<=0.8（降级）
    private boolean useAccessibilityMode = false;

    @Override
    public void onCreate() {
        super.onCreate();
        // 默认使用 Service 自身的 WindowManager（TYPE_APPLICATION_OVERLAY 模式）
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        screenDensity = metrics.densityDpi;

        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        String action = intent.getAction();
        if ("STOP".equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if ("START".equals(action)) {
            int resultCode = intent.getIntExtra("resultCode", 0);
            Intent data = intent.getParcelableExtra("data");
            captureScale = intent.getIntExtra("scale", 50) / 100.0f;
            refineStrength = intent.getIntExtra("strength", 50) / 100.0f;
            frameInterval = intent.getIntExtra("interval", 100);
            useAccessibilityMode = intent.getBooleanExtra("useAccessibility", false);

            captureWidth = (int) (screenWidth * captureScale);
            captureHeight = (int) (screenHeight * captureScale);
            // Ensure even dimensions
            captureWidth = (captureWidth / 2) * 2;
            captureHeight = (captureHeight / 2) * 2;

            startForeground(NOTIFICATION_ID, createNotification());
            startOverlay();
            startCapture(resultCode, data);
        }

        return START_NOT_STICKY;
    }

    private void startOverlay() {
        overlaySurfaceView = new SurfaceView(this);

        int overlayType;
        int windowFlags;
        WindowManager wmToUse;

        if (useAccessibilityMode && TouchForwardingAccessibilityService.isServiceRunning()) {
            // ===== 无障碍模式（推荐）=====
            // 使用 TYPE_ACCESSIBILITY_OVERLAY：这是"可信窗口"类型，
            // 不受 Android 12+ Untrusted Touch Occlusion 限制，
            // FLAG_NOT_TOUCHABLE 可以正常让触摸穿透到任何应用。
            //
            // 必须使用无障碍服务的 Context 获取 WindowManager，
            // 否则系统不允许创建 TYPE_ACCESSIBILITY_OVERLAY 窗口。
            overlayType = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;

            Context a11yContext = TouchForwardingAccessibilityService.getInstance();
            wmToUse = (WindowManager) a11yContext.getSystemService(WINDOW_SERVICE);

            windowFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;

            Log.i(TAG, "Using TYPE_ACCESSIBILITY_OVERLAY (trusted window, full touch passthrough)");
        } else {
            // ===== 传统模式（降级）=====
            // 使用 TYPE_APPLICATION_OVERLAY：在 Android 12+ 上，
            // 此类窗口被视为"不受信任"，系统会阻止触摸穿透到其他应用。
            //
            // 为满足"足够半透明"的豁免条件（alpha <= 0.8），
            // 将窗口 alpha 设为 0.8，使触摸可以穿透到其他应用。
            // 代价是叠加层会有轻微的透明度（20%）。
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            } else {
                overlayType = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
            }

            wmToUse = windowManager;

            windowFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;

            Log.i(TAG, "Using TYPE_APPLICATION_OVERLAY (fallback mode with alpha <= 0.8)");
        }

        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType,
                windowFlags,
                PixelFormat.TRANSLUCENT
        );
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = 0;
        overlayParams.y = 0;

        // Android 12+ Untrusted Touch Occlusion 处理：
        // - TYPE_ACCESSIBILITY_OVERLAY 是可信窗口，alpha 值不影响触摸穿透，设为 1.0 保持最佳显示效果
        // - TYPE_APPLICATION_OVERLAY 需要 alpha <= 0.8 才能满足"足够半透明"的豁免条件
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (useAccessibilityMode && TouchForwardingAccessibilityService.isServiceRunning()) {
                overlayParams.alpha = 1.0f;  // 可信窗口，不受限制
            } else {
                overlayParams.alpha = 0.8f;  // 满足 InputManager.getMaximumObscuringOpacityForTouch()
            }
        }

        overlaySurfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                Log.d(TAG, "Overlay surface created");
                overlayOutputSurface = holder.getSurface();
                surfaceReady = true;
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                Log.d(TAG, "Overlay surface changed: " + width + "x" + height);
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                surfaceReady = false;
                overlayOutputSurface = null;
            }
        });

        overlaySurfaceView.setZOrderOnTop(true);
        overlaySurfaceView.getHolder().setFormat(PixelFormat.TRANSLUCENT);

        // 使用正确的 WindowManager 添加视图
        // （无障碍模式使用无障碍服务的 WM，传统模式使用 Service 自身的 WM）
        wmToUse.addView(overlaySurfaceView, overlayParams);

        // 保存实际使用的 WindowManager 引用，用于后续 removeView
        windowManager = wmToUse;
    }

    private void startCapture(int resultCode, Intent data) {
        processingThread = new HandlerThread("Anime4K-Processing");
        processingThread.start();
        processingHandler = new Handler(processingThread.getLooper());

        MediaProjectionManager projectionManager =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        mediaProjection = projectionManager.getMediaProjection(resultCode, data);

        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                Log.d(TAG, "MediaProjection stopped");
                stopSelf();
            }
        }, processingHandler);

        imageReader = ImageReader.newInstance(captureWidth, captureHeight,
                PixelFormat.RGBA_8888, 2);

        virtualDisplay = mediaProjection.createVirtualDisplay(
                "Anime4KCapture",
                captureWidth, captureHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null, processingHandler
        );

        processingHandler.post(() -> {
            initEGL();
            renderer = new Anime4KRenderer();
            renderer.setRefineStrength(refineStrength);
            renderer.init(captureWidth, captureHeight, screenWidth, screenHeight);
            isRunning = true;
            fpsStartTime = System.currentTimeMillis();
            scheduleNextFrame();
        });
    }

    private void scheduleNextFrame() {
        if (!isRunning) return;
        processingHandler.postDelayed(this::processFrame, frameInterval);
    }

    private void processFrame() {
        if (!isRunning || !surfaceReady) {
            scheduleNextFrame();
            return;
        }

        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) {
                scheduleNextFrame();
                return;
            }

            // Convert Image to Bitmap
            Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            int rowPadding = rowStride - pixelStride * captureWidth;

            Bitmap bitmap = Bitmap.createBitmap(
                    captureWidth + rowPadding / pixelStride,
                    captureHeight,
                    Bitmap.Config.ARGB_8888);
            bitmap.copyPixelsFromBuffer(buffer);

            // Crop if needed
            if (bitmap.getWidth() != captureWidth) {
                Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, captureWidth, captureHeight);
                bitmap.recycle();
                bitmap = cropped;
            }

            image.close();
            image = null;

            // Make EGL context current for offscreen rendering
            makePbufferCurrent();

            // Process through Anime4K
            int outputTex = renderer.process(bitmap);
            bitmap.recycle();

            // Now render to overlay surface
            if (overlayOutputSurface != null && surfaceReady) {
                renderToOverlay(outputTex);
            }

            // FPS counting
            frameCount++;
            long now = System.currentTimeMillis();
            if (now - fpsStartTime >= 1000) {
                float fps = frameCount * 1000.0f / (now - fpsStartTime);
                frameCount = 0;
                fpsStartTime = now;

                Intent fpsIntent = new Intent("com.anime4k.screen.FPS_UPDATE");
                fpsIntent.putExtra("fps", fps);
                fpsIntent.setPackage(getPackageName());
                sendBroadcast(fpsIntent);
            }

        } catch (Exception e) {
            Log.e(TAG, "Error processing frame", e);
            if (image != null) {
                try { image.close(); } catch (Exception ex) {}
            }
        }

        scheduleNextFrame();
    }

    private void renderToOverlay(int texture) {
        try {
            if (eglOverlaySurface == null || eglOverlaySurface == EGL14.EGL_NO_SURFACE) {
                if (overlayOutputSurface != null) {
                    int[] surfaceAttribs = { EGL14.EGL_NONE };
                    eglOverlaySurface = EGL14.eglCreateWindowSurface(
                            eglDisplay, getEGLConfig(), overlayOutputSurface, surfaceAttribs, 0);
                }
            }

            if (eglOverlaySurface == null || eglOverlaySurface == EGL14.EGL_NO_SURFACE) {
                return;
            }

            EGL14.eglMakeCurrent(eglDisplay, eglOverlaySurface, eglOverlaySurface, eglContext);

            // 清空后缓冲区，消除跨帧残影
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            renderer.renderToScreen(texture, screenWidth, screenHeight);

            EGL14.eglSwapBuffers(eglDisplay, eglOverlaySurface);

            // Switch back to pbuffer
            makePbufferCurrent();
        } catch (Exception e) {
            Log.e(TAG, "Error rendering to overlay", e);
            // Reset overlay surface on error
            if (eglOverlaySurface != null && eglOverlaySurface != EGL14.EGL_NO_SURFACE) {
                EGL14.eglDestroySurface(eglDisplay, eglOverlaySurface);
                eglOverlaySurface = null;
            }
        }
    }

    private void initEGL() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        int[] version = new int[2];
        EGL14.eglInitialize(eglDisplay, version, 0, version, 1);

        EGLConfig config = getEGLConfig();

        int[] contextAttribs = {
            EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
            EGL14.EGL_NONE
        };
        eglContext = EGL14.eglCreateContext(eglDisplay, config,
                EGL14.EGL_NO_CONTEXT, contextAttribs, 0);

        // Create PBuffer surface for offscreen rendering
        int[] pbufferAttribs = {
            EGL14.EGL_WIDTH, 1,
            EGL14.EGL_HEIGHT, 1,
            EGL14.EGL_NONE
        };
        eglSurface = EGL14.eglCreatePbufferSurface(eglDisplay, config, pbufferAttribs, 0);

        makePbufferCurrent();
    }

    private void makePbufferCurrent() {
        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext);
    }

    private EGLConfig getEGLConfig() {
        int[] configAttribs = {
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT | EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_NONE
        };
        EGLConfig[] configs = new EGLConfig[1];
        int[] numConfigs = new int[1];
        EGL14.eglChooseConfig(eglDisplay, configAttribs, 0, configs, 0, 1, numConfigs, 0);
        return configs[0];
    }

    private void releaseEGL() {
        if (eglDisplay != null) {
            if (eglOverlaySurface != null && eglOverlaySurface != EGL14.EGL_NO_SURFACE) {
                EGL14.eglDestroySurface(eglDisplay, eglOverlaySurface);
            }
            if (eglSurface != null && eglSurface != EGL14.EGL_NO_SURFACE) {
                EGL14.eglDestroySurface(eglDisplay, eglSurface);
            }
            if (eglContext != null && eglContext != EGL14.EGL_NO_CONTEXT) {
                EGL14.eglDestroyContext(eglDisplay, eglContext);
            }
            EGL14.eglTerminate(eglDisplay);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Anime4K Screen Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Anime4K 屏幕超分服务运行通知");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                notificationIntent, PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, OverlayService.class);
        stopIntent.setAction("STOP");
        PendingIntent stopPendingIntent = PendingIntent.getService(this, 1,
                stopIntent, PendingIntent.FLAG_IMMUTABLE);

        String touchMode;
        if (useAccessibilityMode && TouchForwardingAccessibilityService.isServiceRunning()) {
            touchMode = "无障碍叠加（全局穿透）";
        } else {
            touchMode = "传统穿透（alpha=0.8）";
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        return builder
                .setContentTitle("Anime4K 屏幕超分运行中")
                .setContentText("捕获: " + captureWidth + "x" + captureHeight +
                        " → 输出: " + screenWidth + "x" + screenHeight +
                        " | " + touchMode)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pendingIntent)
                .addAction(android.R.drawable.ic_media_pause, "停止", stopPendingIntent)
                .setOngoing(true)
                .build();
    }

    @Override
    public void onDestroy() {
        isRunning = false;

        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }

        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }

        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }

        if (processingHandler != null) {
            processingHandler.post(() -> {
                if (renderer != null) {
                    renderer.release();
                    renderer = null;
                }
                releaseEGL();
            });
        }

        if (overlaySurfaceView != null) {
            try {
                windowManager.removeView(overlaySurfaceView);
            } catch (Exception e) {
                Log.e(TAG, "Error removing overlay", e);
            }
            overlaySurfaceView = null;
        }

        if (processingThread != null) {
            processingThread.quitSafely();
            processingThread = null;
        }

        // Notify activity
        Intent intent = new Intent("com.anime4k.screen.SERVICE_STOPPED");
        intent.setPackage(getPackageName());
        sendBroadcast(intent);

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
