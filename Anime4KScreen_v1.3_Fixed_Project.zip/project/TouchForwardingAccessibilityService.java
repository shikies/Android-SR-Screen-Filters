package com.anime4k.screen;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

/**
 * 无障碍服务：提供 TYPE_ACCESSIBILITY_OVERLAY 可信窗口支持。
 *
 * v1.3 变更：
 * - 主要用途变更为提供可信窗口上下文（TYPE_ACCESSIBILITY_OVERLAY）
 * - OverlayService 通过 getInstance() 获取此服务的 Context，
 *   用于创建 TYPE_ACCESSIBILITY_OVERLAY 窗口
 * - TYPE_ACCESSIBILITY_OVERLAY 是"可信窗口"，不受 Android 12+
 *   Untrusted Touch Occlusion 限制，FLAG_NOT_TOUCHABLE 可正常穿透
 * - 保留手势转发方法以备将来使用
 */
public class TouchForwardingAccessibilityService extends AccessibilityService {

    private static final String TAG = "TouchForwardA11y";
    private static TouchForwardingAccessibilityService instance;

    private GestureResultCallback gestureCallback = new GestureResultCallback() {
        @Override
        public void onCompleted(GestureDescription gestureDescription) {
            Log.d(TAG, "Gesture completed successfully");
        }

        @Override
        public void onCancelled(GestureDescription gestureDescription) {
            Log.w(TAG, "Gesture was cancelled");
        }
    };

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        Log.i(TAG, "Accessibility service connected — TYPE_ACCESSIBILITY_OVERLAY now available");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // 不需要处理无障碍事件
    }

    @Override
    public void onInterrupt() {
        Log.w(TAG, "Accessibility service interrupted");
    }

    @Override
    public void onDestroy() {
        instance = null;
        Log.i(TAG, "Accessibility service destroyed");
        super.onDestroy();
    }

    /**
     * 获取服务实例。OverlayService 使用此实例的 Context 来创建
     * TYPE_ACCESSIBILITY_OVERLAY 窗口。
     */
    public static TouchForwardingAccessibilityService getInstance() {
        return instance;
    }

    public static boolean isServiceRunning() {
        return instance != null;
    }

    // ===== 以下手势方法保留以备将来使用 =====

    public void performClick(float x, float y) {
        Path clickPath = new Path();
        clickPath.moveTo(x, y);
        GestureDescription.StrokeDescription clickStroke =
                new GestureDescription.StrokeDescription(clickPath, 0, 100);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(clickStroke);
        boolean dispatched = dispatchGesture(builder.build(), gestureCallback, null);
        Log.d(TAG, "Click dispatched at (" + x + ", " + y + "): " + dispatched);
    }

    public void performLongPress(float x, float y, long duration) {
        Path longPressPath = new Path();
        longPressPath.moveTo(x, y);
        GestureDescription.StrokeDescription longPressStroke =
                new GestureDescription.StrokeDescription(longPressPath, 0, Math.max(duration, 500));
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(longPressStroke);
        boolean dispatched = dispatchGesture(builder.build(), gestureCallback, null);
        Log.d(TAG, "Long press dispatched at (" + x + ", " + y + "), duration=" + duration + ": " + dispatched);
    }

    public void performSwipe(float startX, float startY, float endX, float endY, long duration) {
        Path swipePath = new Path();
        swipePath.moveTo(startX, startY);
        swipePath.lineTo(endX, endY);
        GestureDescription.StrokeDescription swipeStroke =
                new GestureDescription.StrokeDescription(swipePath, 0, Math.max(duration, 50));
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(swipeStroke);
        boolean dispatched = dispatchGesture(builder.build(), gestureCallback, null);
        Log.d(TAG, "Swipe dispatched from (" + startX + "," + startY + ") to (" + endX + "," + endY + "), duration=" + duration + ": " + dispatched);
    }

    public void performPinch(float centerX, float centerY, float startSpan, float endSpan, long duration) {
        float halfStartSpan = startSpan / 2;
        float halfEndSpan = endSpan / 2;

        Path finger1Path = new Path();
        finger1Path.moveTo(centerX - halfStartSpan, centerY);
        finger1Path.lineTo(centerX - halfEndSpan, centerY);

        Path finger2Path = new Path();
        finger2Path.moveTo(centerX + halfStartSpan, centerY);
        finger2Path.lineTo(centerX + halfEndSpan, centerY);

        GestureDescription.StrokeDescription stroke1 =
                new GestureDescription.StrokeDescription(finger1Path, 0, Math.max(duration, 50));
        GestureDescription.StrokeDescription stroke2 =
                new GestureDescription.StrokeDescription(finger2Path, 0, Math.max(duration, 50));

        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(stroke1);
        builder.addStroke(stroke2);
        boolean dispatched = dispatchGesture(builder.build(), gestureCallback, null);
        Log.d(TAG, "Pinch dispatched at (" + centerX + "," + centerY + "): " + dispatched);
    }

    public void performGesture(GestureDescription gesture) {
        boolean dispatched = dispatchGesture(gesture, gestureCallback, null);
        Log.d(TAG, "Custom gesture dispatched: " + dispatched);
    }
}
